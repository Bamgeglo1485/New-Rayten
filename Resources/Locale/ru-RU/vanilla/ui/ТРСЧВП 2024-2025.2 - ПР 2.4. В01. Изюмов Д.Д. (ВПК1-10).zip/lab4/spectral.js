function ensureValidArray(arr, name = 'Array') {
  if (!Array.isArray(arr)) throw new Error(`${name} is not an array`);
  if (arr.length > 50) throw new Error(`${name} length must be ≤ 50`);
  for (const val of arr) {
    if (!Number.isInteger(val)) throw new Error(`${name} contains non-integer value`);
    if (val < 0 || val > 500) throw new Error(`${name} contains value out of range (0–500)`);
  }
}

function arraysEqualIgnoreOrder(a, b) {
  if (a.length !== b.length) return false;
  const sortedA = [...a].sort((x, y) => x - y);
  const sortedB = [...b].sort((x, y) => x - y);
  return sortedA.every((val, idx) => val === sortedB[idx]);
}

function getSpectralDeviationSequence(m1, m2) {
  ensureValidArray(m1, 'm1');
  ensureValidArray(m2, 'm2');

  const unique = new Set([...m1, ...m2]);
  const spectrum = Array.from(unique).sort((a, b) => a - b);

  const freq1 = new Map(spectrum.map(v => [v, 0]));
  const freq2 = new Map(spectrum.map(v => [v, 0]));

  for (const n of m1) freq1.set(n, freq1.get(n) + 1);
  for (const n of m2) freq2.set(n, freq2.get(n) + 1);

  const deviation = spectrum.map(v => freq1.get(v) - freq2.get(v)); 
  return { spectrum, deviation };
}


module.exports = {
  getSpectralDeviationSequence,
  ensureValidArray,
  arraysEqualIgnoreOrder,
};
