const {
  getSpectralDeviationSequence,
  ensureValidArray,
  arraysEqualIgnoreOrder
} = require('./spectral');

describe('ensureValidArray', () => {
  test('допускает пустой массив', () => {
    expect(() => ensureValidArray([])).not.toThrow();
  });

  test('ошибка при длине > 50', () => {
    const longArr = Array(51).fill(1);
    expect(() => ensureValidArray(longArr)).toThrow(/length/);
  });

  test('ошибка при нецелых значениях', () => {
    expect(() => ensureValidArray([1.5, 2])).toThrow(/non-integer/);
  });

  test('ошибка при значениях < 0', () => {
    expect(() => ensureValidArray([-1, 2])).toThrow(/out of range/);
  });

  test('ошибка при значениях > 500', () => {
    expect(() => ensureValidArray([0, 600])).toThrow(/out of range/);
  });

  test('работает с граничными значениями 0 и 500', () => {
    expect(() => ensureValidArray([0, 500])).not.toThrow();
  });

  test('ошибка при строке вместо числа', () => {
    expect(() => ensureValidArray([1, '2'])).toThrow();
  });

  test('ошибка при undefined', () => {
    expect(() => ensureValidArray([1, undefined])).toThrow();
  });

  test('ошибка при объекте', () => {
    expect(() => ensureValidArray([1, {}])).toThrow();
  });
});

describe('arraysEqualIgnoreOrder', () => {
  test('распознаёт одинаковые массивы без порядка', () => {
    expect(arraysEqualIgnoreOrder([1, 2, 3], [3, 1, 2])).toBe(true);
  });

  test('разные массивы дают false', () => {
    expect(arraysEqualIgnoreOrder([1, 2], [1, 2, 3])).toBe(false);
  });

  test('одинаковые с повторениями и порядком', () => {
    expect(arraysEqualIgnoreOrder([1, 1, 2], [2, 1, 1])).toBe(true);
  });

  test('повторения в одном массиве дают false', () => {
    expect(arraysEqualIgnoreOrder([1, 2], [1, 1, 2])).toBe(false);
  });
});

describe('getSpectralDeviationSequence', () => {
  test('корректный результат на базовом примере', () => {
    const m1 = [1, 2, 3, 2, 5, 3, 5];
    const m2 = [2, 4, 9, 4, 2, 3, 7, 2, 5, 5];
    const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
    expect(spectrum).toEqual([1, 2, 3, 4, 5, 7, 9]);
    expect(deviation).toEqual([1, -1, 1, -2, 0, -1, -1]);
  });

  test('оба массива пусты', () => {
    const { spectrum, deviation } = getSpectralDeviationSequence([], []);
    expect(spectrum).toEqual([]);
    expect(deviation).toEqual([]);
  });

 test('все элементы m2 меньше', () => {
  const m1 = [1, 1, 1, 2, 3];
  const m2 = [1, 1, 1];
  const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
  
  expect(spectrum).toEqual([1, 2, 3]);  
  expect(deviation).toEqual([0, 1, 1]);
  });

  test('массивы с одним элементом', () => {
    const m1 = [1];
    const m2 = [1];
    const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
    
    expect(spectrum).toEqual([1]);  
    expect(deviation).toEqual([0]);
  });

  test('массив m1 содержит значения, которых нет в m2', () => {
    const m1 = [1, 2, 3];
    const m2 = [3, 4, 5];
    const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
    
    expect(spectrum).toEqual([1, 2, 3, 4, 5]);  
    expect(deviation).toEqual([1, 1, 0, -1, -1]);
  });

  test('значения m2 = значения m1, переставлены', () => {
    const m1 = [1, 2, 3];
    const m2 = [3, 2, 1];
    const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
    
    expect(spectrum).toEqual([1, 2, 3]);  
    expect(deviation).toEqual([0, 0, 0]);
  });

  test('m2 содержит больше повторений', () => {
    const m1 = [1, 2];
    const m2 = [1, 1, 2, 2];
    const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
    
    expect(spectrum).toEqual([1, 2]);  
    expect(deviation).toEqual([-1, -1]);
  });

  test('m2 содержит меньше повторений', () => {
    const m1 = [1, 1, 2, 2];
    const m2 = [1, 2];
    const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
    
    expect(spectrum).toEqual([1, 2]);  
    expect(deviation).toEqual([1, 1]);
  });


  test('границы диапазона: 0 и 500', () => {
    const m1 = [0];
    const m2 = [500];
    const { spectrum, deviation } = getSpectralDeviationSequence(m1, m2);
    expect(spectrum).toEqual([0, 500]);
    expect(deviation).toEqual([1, -1]);
  });

  test('корректный расчёт спектральной разности', () => {
    const m1 = [1, 2, 3];
    const m2 = [2, 3, 4];
    const { deviation } = getSpectralDeviationSequence(m1, m2);
    const spectralDistance = deviation.reduce((sum, d) => sum + d ** 2, 0);
    expect(spectralDistance).toBe(2);
  });
});
